
package org.example.enums;
public enum TileKind { GROUND, BRICK, PIPE, SPIKE, GOAL }
