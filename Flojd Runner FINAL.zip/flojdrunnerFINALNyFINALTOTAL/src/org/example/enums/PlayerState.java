
package org.example.enums;
public enum PlayerState { IDLE, RUN, JUMP, FALL, DEAD }
