
package org.example.enums;
public enum GameState { RUNNING, GAME_OVER }
