
package org.example.enums;
public enum AIState { CHASE, JUMP, WAIT }
