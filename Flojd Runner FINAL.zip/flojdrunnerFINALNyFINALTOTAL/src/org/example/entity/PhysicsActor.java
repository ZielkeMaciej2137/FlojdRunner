
package org.example.entity;

import java.awt.Rectangle;
import org.example.core.GameContext;
import org.example.level.Block;

public abstract class PhysicsActor extends Entity {
    protected boolean onGround = false;
    protected boolean touchLeftWall = false;
    protected boolean touchRightWall = false;

    protected float moveSpeed = 220f;
    protected float jumpSpeed = 460f;
    protected float gravity = 1400f;
    protected float maxFall = 980f;

    private static final float EPS = 0.01f;

    public PhysicsActor(float x, float y, int w, int h) { super(x, y, w, h); }

    protected void applyGravity(float dt) {
        float vy = getVy() + gravity * dt;
        if (vy > maxFall) vy = maxFall;
        setVy(vy);
    }

    protected void moveAndCollideX(GameContext ctx) {
        setX(getX() + getVx() * ctx.dt());
        touchLeftWall = false;
        touchRightWall = false;

        Rectangle me = getBounds();
        for (Block b : ctx.blocks()) {
            if (!ctx.isSolid(b.kind)) continue;
            if (me.intersects(b.rect)) {
                if (getVx() > 0) {
                    setX(b.rect.x - getW() - EPS);
                    touchRightWall = true;
                } else if (getVx() < 0) {
                    setX(b.rect.x + b.rect.width + EPS);
                    touchLeftWall = true;
                }
                setVx(0);
                me = getBounds();
            }
        }
    }

    protected void moveAndCollideY(GameContext ctx) {
        setY(getY() + getVy() * ctx.dt());
        onGround = false;
        Rectangle me = getBounds();
        for (Block b : ctx.blocks()) {
            if (!ctx.isSolid(b.kind)) continue;
            if (me.intersects(b.rect)) {
                if (getVy() > 0) {
                    setY(b.rect.y - getH() - EPS);
                    onGround = true;
                } else if (getVy() < 0) {
                    setY(b.rect.y + b.rect.height + EPS);
                }
                setVy(0);
                me = getBounds();
            }
        }
    }

    protected void jump() { jump(jumpSpeed); }
    protected void jump(float strength) { setVy(-strength); }
}
