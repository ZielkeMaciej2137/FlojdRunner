package org.example.entity.item;

import org.example.core.GameContext;
import org.example.entity.Entity;
import org.example.level.Block;
import org.example.enums.TileKind;

import java.awt.*;
import java.util.List;
import java.util.Random;

public class Coin extends Entity {

    private static final Random RNG = new Random();
    private boolean collected = false;

    public Coin(float x, float y) {
        super(x, y, 16, 16);
    }

    // ================== FABRYKA MONET ==================
    public static Coin random(List<Block> blocks) {
        java.util.ArrayList<Block> eligible = new java.util.ArrayList<>();
        for (Block b : blocks) {
            if (b.kind == TileKind.GROUND || b.kind == TileKind.BRICK || b.kind == TileKind.PIPE) {
                eligible.add(b);
            }
        }
        if (eligible.isEmpty()) {
            return new Coin(0, 0);
        }

        final int CW = 16, CH = 16;

        for (int attempt = 0; attempt < 800; attempt++) {
            Block b = eligible.get(RNG.nextInt(eligible.size()));


            float x = b.rect.x + RNG.nextFloat() * Math.max(1, b.rect.width - CW);
            int margin = 6 + RNG.nextInt(18);
            float y = b.rect.y - CH - margin;
            if (y < 0) continue;

            Coin c = new Coin(x, y);


            Rectangle r = c.getBounds();
            boolean ok = true;
            for (Block other : blocks) {
                if (other.kind == TileKind.GROUND || other.kind == TileKind.BRICK || other.kind == TileKind.PIPE) {
                    if (r.intersects(other.rect)) {
                        ok = false;
                        break;
                    }
                }
            }
            if (ok) return c;
        }


        Block b = eligible.get(0);
        return new Coin(b.rect.x + 2, b.rect.y - 22);
    }

    // ================== LOGIKA ==================
    @Override
    public void update(GameContext ctx) {
        if (!collected && getBounds().intersects(ctx.player().getBounds())) {
            collected = true;
        }
    }

    public boolean isCollected() {
        return collected;
    }

    // ================== RENDER ==================
    @Override
    public void render(Graphics2D g) {
        if (collected) return;

        g.setColor(Color.YELLOW);
        g.fillOval((int) getX(), (int) getY(), getW(), getH());
        g.setColor(Color.ORANGE);
        g.drawOval((int) getX(), (int) getY(), getW(), getH());
    }
}
