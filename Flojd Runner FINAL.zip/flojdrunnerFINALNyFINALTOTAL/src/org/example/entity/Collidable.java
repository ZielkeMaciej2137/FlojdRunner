
package org.example.entity;
import java.awt.Rectangle;
public interface Collidable { Rectangle getBounds(); }
