
package org.example.entity.player;

import org.example.entity.PhysicsActor;
import org.example.core.GameContext;
import org.example.enums.*;
import org.example.input.Controllable;
import org.example.level.Block;

import java.awt.*;

public class Player extends PhysicsActor {
    private Direction dir = Direction.RIGHT;
    private PlayerState state = PlayerState.IDLE;


    private float coyoteTime = 0f;
    private float jumpBuffer = 0f;
    private static final float COYOTE_MAX = 0.10f;
    private static final float BUFFER_MAX = 0.10f;

    public Player(float x, float y) { super(x, y, 22, 28); }
    public Player(Point startTopCenter) { super(startTopCenter.x - 11, startTopCenter.y - 28, 22, 28); }

    @Override
    public void update(GameContext ctx) {
        if (ctx.gameState() == GameState.GAME_OVER) return;

        Controllable in = ctx.input();
        float dt = ctx.dt();

        // Timers for responsive jumping
        if (onGround) coyoteTime = COYOTE_MAX;
        else coyoteTime = Math.max(0f, coyoteTime - dt);
        jumpBuffer = Math.max(0f, jumpBuffer - dt);

        float target = 0f;
        if (in.isLeft()) { target -= moveSpeed; dir = Direction.LEFT; }
        if (in.isRight()) { target += moveSpeed; dir = Direction.RIGHT; }

        float ax = 2200f;
        float vx = getVx();
        vx += (target - vx) * Math.min(1f, ax * dt / Math.max(1f, moveSpeed));
        if (!in.isLeft() && !in.isRight()) vx *= 0.85f;
        if (Math.abs(vx) < 5f) vx = 0f;
        setVx(vx);


        if (in.consumeJumpPressed()) {
            jumpBuffer = BUFFER_MAX;
        }


        if (jumpBuffer > 0f) {
            if (coyoteTime > 0f) {
                jump();
                onGround = false;
                coyoteTime = 0f;
                jumpBuffer = 0f;
            } else if (touchLeftWall) {
                jump(jumpSpeed * 0.98f);
                setVx(280f);
                jumpBuffer = 0f;
            } else if (touchRightWall) {
                jump(jumpSpeed * 0.98f);
                setVx(-280f);
                jumpBuffer = 0f;
            }
        }

        applyGravity(dt);


        if (!in.isJumpHeld() && getVy() < 0) {
            setVy(getVy() + gravity * dt * 1.6f);
        }

        moveAndCollideX(ctx);
        moveAndCollideY(ctx);

        if (!onGround) state = (getVy() < 0) ? PlayerState.JUMP : PlayerState.FALL;
        else state = (Math.abs(getVx()) > 30) ? PlayerState.RUN : PlayerState.IDLE;

        for (Block b : ctx.blocks()) {
            if (b.kind == org.example.enums.TileKind.SPIKE && getBounds().intersects(b.rect)) {
                state = PlayerState.DEAD;
                ctx.requestGameOver("KONIEC GRY");
                break;
            }
        }
    }

    @Override
    public void render(java.awt.Graphics2D g) {
        int rx = Math.round(getX());
        int ry = Math.round(getY());
        g.setColor(new Color(30, 90, 255));
        g.fillRoundRect(rx, ry, getW(), getH(), 8, 8);

        g.setColor(Color.WHITE);
        int eyeX = (dir == Direction.RIGHT) ? rx + getW() - 10 : rx + 4;
        g.fillOval(eyeX, ry + 6, 6, 6);
    }

    public PlayerState getState() { return state; }
}
