
package org.example.entity.enemy;

import org.example.entity.PhysicsActor;
import org.example.core.GameContext;
import org.example.core.Difficulty;
import org.example.entity.player.Player;
import org.example.enums.*;

import java.awt.*;

public class Ghost extends PhysicsActor {

    private Direction dir = Direction.LEFT;
    private AIState state = AIState.CHASE;

    private float decisionCooldown = 0f;


    private float chaseSeconds = 3.0f;
    private float restSeconds = 2.0f;
    private float phaseLeft = 3.0f;
    private boolean resting = false;

    public Ghost(float x, float y) {
        super(x, y, 24, 24);
        this.moveSpeed = 200f;
        this.jumpSpeed = 420f;


        this.chaseSeconds = 3.0f;
        this.restSeconds = 2.0f;
        this.phaseLeft = this.chaseSeconds;
        this.resting = false;
    }

    public Ghost(Point p, Difficulty difficulty) {
        this(p.x, p.y);
        this.moveSpeed = difficulty.ghostSpeed;
        this.chaseSeconds = difficulty.chaseSeconds;
        this.restSeconds = difficulty.restSeconds;
        this.phaseLeft = this.chaseSeconds;
        this.resting = false;
    }

    @Override
    public void update(GameContext ctx) {
        if (ctx.gameState() == GameState.GAME_OVER) return;

        Player player = ctx.player();
        float dt = ctx.dt();


        phaseLeft -= dt;
        if (phaseLeft <= 0f) {
            resting = !resting;
            phaseLeft = resting ? restSeconds : chaseSeconds;
        }

        decisionCooldown -= dt;

        boolean wantLeft = !resting && (player.getX() < getX() - 4);
        boolean wantRight = !resting && (player.getX() > getX() + 4);

        float target = 0f;
        if (wantLeft) {
            target = -moveSpeed;
            dir = Direction.LEFT;
        } else if (wantRight) {
            target = moveSpeed;
            dir = Direction.RIGHT;
        }

        float ax = 1800f;
        float vx = getVx();
        vx += (target - vx) * Math.min(1f, ax * dt / Math.max(1f, moveSpeed));
        if (!wantLeft && !wantRight) vx *= 0.90f;
        setVx(vx);

        applyGravity(dt);

        moveAndCollideX(ctx);
        moveAndCollideY(ctx);


        if (!resting) {
            boolean playerAbove = player.getY() + player.getH() < getY();
            boolean wallAhead =
                    (dir == Direction.LEFT && touchLeftWall) ||
                            (dir == Direction.RIGHT && touchRightWall);

            boolean touchingAnyWall = touchLeftWall || touchRightWall;
            boolean groundAhead = isGroundAhead(ctx);

            if (!groundAhead && onGround && decisionCooldown <= 0f) {
                jump();
                decisionCooldown = 0.30f;
            }

            if (playerAbove && onGround && decisionCooldown <= 0f) {
                jump();
                decisionCooldown = 0.30f;
            }

            if (wallAhead && onGround && decisionCooldown <= 0f) {
                jump();
                decisionCooldown = 0.30f;
            }

            boolean pushingIntoWall =
                    (dir == Direction.LEFT && touchLeftWall) ||
                            (dir == Direction.RIGHT && touchRightWall);

            if (!onGround && touchingAnyWall && pushingIntoWall && decisionCooldown <= 0f) {
                if (playerAbove || wallAhead) {
                    jump(jumpSpeed * 0.95f);

                    if (touchLeftWall) {
                        setVx(260f);
                        dir = Direction.RIGHT;
                    } else if (touchRightWall) {
                        setVx(-260f);
                        dir = Direction.LEFT;
                    }

                    decisionCooldown = 0.25f;
                }
            }
        }

        if (getBounds().intersects(player.getBounds())) {
            ctx.requestGameOver("KONIEC GRY");
        }
    }

    private boolean isGroundAhead(GameContext ctx) {
        int lookX = (dir == Direction.RIGHT)
                ? (int)(getX() + getW() + 4)
                : (int)(getX() - 4);

        int lookY = (int)(getY() + getH() + 4);

        java.awt.Rectangle probe = new java.awt.Rectangle(lookX, lookY, 4, 4);

        for (org.example.level.Block b : ctx.blocks()) {
            if (ctx.isSolid(b.kind) && b.rect.intersects(probe)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public void render(java.awt.Graphics2D g) {
        int rx = Math.round(getX());
        int ry = Math.round(getY());


        int alpha = resting ? 120 : 200;
        g.setColor(new Color(220, 220, 255, alpha));
        g.fillOval(rx, ry, getW(), getH());

        g.setColor(new Color(80, 80, 160));
        g.drawOval(rx, ry, getW(), getH());

        g.setColor(Color.BLACK);
        g.fillOval(rx + 7, ry + 8, 4, 4);
        g.fillOval(rx + 14, ry + 8, 4, 4);
    }
}
