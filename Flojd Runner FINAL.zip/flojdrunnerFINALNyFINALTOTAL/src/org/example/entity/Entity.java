
package org.example.entity;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import org.example.core.GameContext;

public abstract class Entity implements Collidable {
    private float x, y;
    private float vx, vy;
    private final int w, h;

    public Entity(float x, float y, int w, int h) { this.x = x; this.y = y; this.w = w; this.h = h; }
    public Entity(int w, int h) { this(0,0,w,h); }

    public abstract void update(GameContext ctx);
    public abstract void render(Graphics2D g);

    public float getX() { return x; }
    public float getY() { return y; }
    public void setX(float x) { this.x = x; }
    public void setY(float y) { this.y = y; }
    public float getVx() { return vx; }
    public float getVy() { return vy; }
    public void setVx(float vx) { this.vx = vx; }
    public void setVy(float vy) { this.vy = vy; }
    public int getW() { return w; }
    public int getH() { return h; }

    @Override
    public Rectangle getBounds() {
        int rx = Math.round(x);
        int ry = Math.round(y);
        return new Rectangle(rx, ry, w, h);
    }
}
