
package org.example.input;
public class InputState implements Controllable {
    private boolean left, right;
    private boolean jumpEdge;
    private boolean jumpHeld;

    public void setLeft(boolean v) { left = v; }
    public void setRight(boolean v) { right = v; }
    public void pressJump() { jumpEdge = true; jumpHeld = true; }
    public void releaseJump() { jumpHeld = false; }

    @Override public boolean isLeft() { return left; }
    @Override public boolean isRight() { return right; }

    @Override
    public boolean consumeJumpPressed() {
        boolean was = jumpEdge;
        jumpEdge = false;
        return was;
    }

    @Override
    public boolean isJumpHeld() {
        return jumpHeld;
    }
}
