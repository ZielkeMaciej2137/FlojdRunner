
package org.example.input;
public interface Controllable {
    boolean isLeft();
    boolean isRight();
    boolean consumeJumpPressed();


    boolean isJumpHeld();
}
