package org.example;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;

import org.example.core.Difficulty;
import org.example.core.GamePanel;
import org.example.core.MainMenuPanel;

public class Game {

    public static JFrame frame;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            frame = new JFrame("Platformer");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setUndecorated(true);
            frame.setResizable(false);

            showMenu();

            frame.setVisible(true);
            enableFullscreen(frame);
        });
    }

    private static void enableFullscreen(JFrame f) {
        try {
            GraphicsDevice gd = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice();
            if (gd.isFullScreenSupported()) {
                gd.setFullScreenWindow(f);
            } else {
                f.setExtendedState(JFrame.MAXIMIZED_BOTH);
                f.setLocationRelativeTo(null);
            }
        } catch (Exception ex) {
            f.setExtendedState(JFrame.MAXIMIZED_BOTH);
            f.setLocationRelativeTo(null);
        }
    }

    public static void showMenu() {
        frame.setContentPane(new MainMenuPanel());
        frame.revalidate();
        frame.repaint();
    }

    public static void startGame(Difficulty difficulty) {
        GamePanel panel = new GamePanel(difficulty);
        frame.setContentPane(panel);
        frame.revalidate();
        panel.requestFocusInWindow();
    }
}
