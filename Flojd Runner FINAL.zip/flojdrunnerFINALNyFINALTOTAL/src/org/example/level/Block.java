
package org.example.level;

import java.awt.Rectangle;
import org.example.enums.TileKind;

public class Block {
    public final Rectangle rect;
    public final TileKind kind;

    public Block(Rectangle rect, TileKind kind) {
        this.rect = rect;
        this.kind = kind;
    }
}
