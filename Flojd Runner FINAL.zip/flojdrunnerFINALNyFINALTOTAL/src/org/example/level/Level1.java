
package org.example.level;

import java.awt.Point;
import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.List;
import org.example.enums.TileKind;

public class Level1 {
    public static final int TILE = 32;
    public static final int W_TILES = 40;
    public static final int H_TILES = 18;
    public static final Point PLAYER_START_PX = tileTopCenter(20, 13);

    public static List<Block> build() {
        ArrayList<Block> L = new ArrayList<>();

        addRect(L, 0, 17, 40, 1, TileKind.GROUND);
        addRect(L, 2, 16, 2, 1, TileKind.GROUND);
        addRect(L, 6, 16, 3, 1, TileKind.GROUND);
        addRect(L, 11, 16, 2, 1, TileKind.GROUND);
        addRect(L, 24, 16, 3, 1, TileKind.GROUND);
        addRect(L, 33, 16, 2, 1, TileKind.GROUND);

        addRect(L, 0, 0, 1, 18, TileKind.PIPE);
        addRect(L, 4, 12, 1, 5, TileKind.PIPE);
        addRect(L, 10, 13, 4, 1, TileKind.BRICK);

        addRect(L, 3, 9, 2, 1, TileKind.BRICK);
        addRect(L, 6, 7, 3, 1, TileKind.BRICK);
        addRect(L, 9, 10, 4, 1, TileKind.BRICK);
        addRect(L, 10, 5, 5, 1, TileKind.BRICK);

        addRect(L, 19, 9, 1, 8, TileKind.PIPE);
        addRect(L, 20, 13, 2, 1, TileKind.BRICK);
        addRect(L, 16, 7, 2, 1, TileKind.BRICK);

        addRect(L, 16, 11, 3, 1, TileKind.BRICK);
        addRect(L, 24, 10, 3, 1, TileKind.BRICK);
        addRect(L, 22, 6, 1, 3, TileKind.PIPE);

        addRect(L, 25, 5, 6, 1, TileKind.BRICK);
        addRect(L, 29, 9, 2, 1, TileKind.BRICK);
        addRect(L, 32, 8, 1, 4, TileKind.PIPE);
        addRect(L, 35, 12, 2, 1, TileKind.BRICK);

        addRect(L, 15, 16, 1, 1, TileKind.SPIKE);
        addRect(L, 30, 16, 1, 1, TileKind.SPIKE);

        addRect(L, 39, 0, 1, 18, TileKind.PIPE);
        addRect(L, 26, 13, 2, 1, TileKind.BRICK);
        addRect(L, 20, 13, 2, 1, TileKind.BRICK);
        addRect(L, 34, 5, 2, 1, TileKind.BRICK);

        addRect(L, 0, 2, 1, 5, TileKind.PIPE);
        addRect(L, 4, 3, 2, 1, TileKind.BRICK);
        addRect(L, 12, 2, 1, 3, TileKind.PIPE);
        addRect(L, 19, 2, 1, 3, TileKind.PIPE);
        addRect(L, 20, 2, 3, 1, TileKind.BRICK);
        addRect(L, 27, 0, 1, 3, TileKind.PIPE);
        addRect(L, 32, 2, 4, 1, TileKind.BRICK);

        return L;
    }

    private static void addRect(List<Block> L, int tx, int ty, int tw, int th, TileKind kind) {
        Rectangle r = new Rectangle(tx * TILE, ty * TILE, tw * TILE, th * TILE);
        L.add(new Block(r, kind));
    }

    private static Point tileTopCenter(int tx, int ty) {
        int x = tx * TILE + TILE / 2;
        int y = ty * TILE;
        return new Point(x, y);
    }
}
