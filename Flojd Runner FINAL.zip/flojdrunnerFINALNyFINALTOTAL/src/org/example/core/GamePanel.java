package org.example.core;

import org.example.entity.Entity;
import org.example.entity.enemy.Ghost;
import org.example.entity.item.Coin;
import org.example.entity.player.Player;
import org.example.input.InputState;
import org.example.level.Block;
import org.example.level.Level1;
import org.example.enums.*;
import org.example.Game;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class GamePanel extends JPanel {

    private final Difficulty difficulty;

    private List<Block> blocks;
    private final List<Entity> entities = new ArrayList<>();

    private final InputState input = new InputState();

    private Player player;
    private Ghost ghost;
    private int score = 0;
    private int totalCoins = 0;



    private GameState gameState = GameState.RUNNING;
    private String gameOverText = "";

    private Timer timer;
    private long lastNanos;

    private final int baseW;
    private final int baseH;

    // ================= CONSTRUCTOR =================
    public GamePanel(Difficulty difficulty) {
        this.difficulty = difficulty;

        setBackground(new Color(135, 206, 235));
        setFocusable(true);

        blocks = Level1.build();

        baseW = Level1.W_TILES * Level1.TILE;
        baseH = Level1.H_TILES * Level1.TILE;

        bindControls();
        resetWorld();

        lastNanos = System.nanoTime();
        timer = new Timer(16, e -> tick());
        timer.start();
    }

    // ================= WORLD =================
    private void resetWorld() {
        entities.clear();

        score = 0;

        player = new Player(Level1.PLAYER_START_PX);
        ghost = new Ghost(new Point(60, 60), difficulty);

        entities.add(player);
        entities.add(ghost);

        spawnCoins();

        gameState = GameState.RUNNING;
    }

    private void spawnCoins() {
        int count = switch (difficulty) {
            case EASY -> 12;
            case NORMAL -> 20;
            case HARD -> 32;
            case INSANE -> 48;
        };

        totalCoins = count;

        int added = 0;
        int attempts = 0;
        while (added < count && attempts < 5000) {
            attempts++;
            Coin c = Coin.random(blocks);


            boolean ok = !c.getBounds().intersects(player.getBounds()) && !c.getBounds().intersects(ghost.getBounds());
            if (ok) {
                for (Entity e : entities) {
                    if (e instanceof Coin existing && existing.getBounds().intersects(c.getBounds())) {
                        ok = false;
                        break;
                    }
                }
            }

            if (ok) {
                entities.add(c);
                added++;
            }
        }
        totalCoins = added;
    }


    // ================= GAME LOOP =================
    private void tick() {
        long now = System.nanoTime();
        float dt = (now - lastNanos) / 1_000_000_000f;
        lastNanos = now;
        if (dt > 0.05f) dt = 0.05f;

        GameContext ctx = new GameContext(
                blocks,
                input,
                dt,
                player,
                gameState,
                this::gameOver,
                this::addScore
        );

        for (Entity e : new ArrayList<>(entities)) {
            e.update(ctx);
        }

        Iterator<Entity> it = entities.iterator();
        while (it.hasNext()) {
            Entity e = it.next();
            if (e instanceof Coin c && c.isCollected()) {
                it.remove();
                score++;
            }
        }


        if (score == totalCoins && gameState == GameState.RUNNING) {
            gameOver("WYGRANA!");
        }



        repaint();
    }
    private void addScore(int v) {
        score += v;
    }

    private void gameOver(String msg) {
        if (gameState == GameState.GAME_OVER) return;
        gameState = GameState.GAME_OVER;
        gameOverText = msg;
        timer.stop();
    }

    // ================= INPUT =================
    private void bindControls() {
        getInputMap(WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke("pressed A"), "left");
        getActionMap().put("left", new AbstractAction() {
            public void actionPerformed(ActionEvent e) { input.setLeft(true); }
        });

        getInputMap(WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke("released A"), "left_up");
        getActionMap().put("left_up", new AbstractAction() {
            public void actionPerformed(ActionEvent e) { input.setLeft(false); }
        });

        getInputMap(WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke("pressed D"), "right");
        getActionMap().put("right", new AbstractAction() {
            public void actionPerformed(ActionEvent e) { input.setRight(true); }
        });

        getInputMap(WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke("released D"), "right_up");
        getActionMap().put("right_up", new AbstractAction() {
            public void actionPerformed(ActionEvent e) { input.setRight(false); }
        });

        getInputMap(WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke("pressed SPACE"), "jump");
        getActionMap().put("jump", new AbstractAction() {
            public void actionPerformed(ActionEvent e) { input.pressJump(); }
        });

        getInputMap(WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke("released SPACE"), "jump_up");
        getActionMap().put("jump_up", new AbstractAction() {
            public void actionPerformed(ActionEvent e) { input.releaseJump(); }
        });

        // Return to main menu (useful in fullscreen).
        getInputMap(WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke("pressed ESCAPE"), "menu");
        getActionMap().put("menu", new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                if (timer != null) timer.stop();
                Game.showMenu();
            }
        });
    }

    // ================= RENDER =================
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;


        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g2.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);


        g2.setColor(Color.BLACK);
        g2.drawString("Score: " + score + " / " + totalCoins, 10, 32);
        g2.drawString("Difficulty: " + difficulty, 10, 16);


        var oldTx = g2.getTransform();
        double sx = getWidth() / (double) baseW;
        double sy = getHeight() / (double) baseH;
        double s = Math.min(sx, sy);
        double ox = (getWidth() - baseW * s) / 2.0;
        double oy = (getHeight() - baseH * s) / 2.0;
        g2.translate(ox, oy);
        g2.scale(s, s);

        for (Block b : blocks) {
            switch (b.kind) {
                case GROUND -> g2.setColor(new Color(139, 69, 19));
                case BRICK -> g2.setColor(new Color(205, 133, 63));
                case PIPE -> g2.setColor(Color.GREEN.darker());
                case SPIKE -> g2.setColor(Color.RED);
            }
            g2.fillRect(b.rect.x, b.rect.y, b.rect.width, b.rect.height);
        }

        for (Entity e : entities) e.render(g2);


        g2.setTransform(oldTx);

        if (gameState == GameState.GAME_OVER) {
            g2.setColor(new Color(0, 0, 0, 160));
            g2.fillRect(0, 0, getWidth(), getHeight());
            g2.setColor(Color.WHITE);
            g2.setFont(g2.getFont().deriveFont(Font.BOLD, 48f));
            FontMetrics fm = g2.getFontMetrics();
            int tw = fm.stringWidth(gameOverText);
            g2.drawString(gameOverText, (getWidth() - tw) / 2, getHeight() / 2);
            g2.setFont(g2.getFont().deriveFont(Font.PLAIN, 16f));
            g2.drawString("ESC - menu", 10, getHeight() - 10);
        }
    }
}
