
package org.example.core;

import java.util.List;
import java.util.function.Consumer;
import java.util.function.IntConsumer;
import org.example.level.Block;
import org.example.enums.*;
import org.example.input.InputState;
import org.example.entity.player.Player;

public class GameContext {
    private final List<Block> blocks;
    private final InputState input;
    private final float dt;
    private final Player player;
    private final GameState gameState;
    private final Consumer<String> gameOverHook;
    private final IntConsumer scoreHook;

    public GameContext(List<Block> blocks, InputState input, float dt, Player player, GameState gameState, Consumer<String> gameOverHook, IntConsumer scoreHook) {
        this.blocks = blocks; this.input = input; this.dt = dt; this.player = player; this.gameState = gameState; this.gameOverHook = gameOverHook; this.scoreHook = scoreHook;
    }

    public List<Block> blocks() { return blocks; }
    public InputState input() { return input; }
    public float dt() { return dt; }
    public Player player() { return player; }
    public GameState gameState() { return gameState; }

    public boolean isSolid(org.example.enums.TileKind k) {
        return k == TileKind.GROUND || k == TileKind.BRICK || k == TileKind.PIPE;
    }

    public void requestGameOver(String m) { gameOverHook.accept(m); }
    public void addScore(int v) { scoreHook.accept(v); }
}
