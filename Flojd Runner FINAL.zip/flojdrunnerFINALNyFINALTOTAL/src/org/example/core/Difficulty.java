package org.example.core;

public enum Difficulty {
    EASY(150f, 0.5f, 2.0f, 3.0f),
    NORMAL(200f, 1f, 3.0f, 2.0f),
    HARD(260f, 1.5f, 4.0f, 1.5f),
    INSANE(300f, 2f, 5.0f, 1.0f);

    public final float ghostSpeed;
    public final float coinRate;
    public final float chaseSeconds;
    public final float restSeconds;

    Difficulty(float ghostSpeed, float coinRate, float chaseSeconds, float restSeconds) {
        this.ghostSpeed = ghostSpeed;
        this.coinRate = coinRate;
        this.chaseSeconds = chaseSeconds;
        this.restSeconds = restSeconds;
    }
}
